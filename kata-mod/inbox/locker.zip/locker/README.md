# Locker

Grey steel school lockers in the style of Japanese school lockers, built for Blockbench in the Bedrock/GeckoLib format, so the geometry and animations load straight into a GeckoLib block entity.

## Files

| file | what it is |
|---|---|
| `locker.bbmodel` | The interactive locker, with its animations. |
| `locker_deco_shoes.bbmodel` | Decorative, door open 118°: a pair of indoor shoes (uwabaki), put away heel-out. |
| `locker_deco_sneakers.bbmodel` | Decorative, cream door open 96°: navy sneakers (one kicked in sideways) and a plastic bag. |
| `locker_deco_towel.bbmodel` | Decorative, door ajar 34° with a towel hung over it, and a stack of books inside. |
| `locker_deco_pouch.bbmodel` | Decorative, door open 112°: a drawstring pouch on the coat hook, indoor shoes, and a paper tag on the lock. |
| `locker_deco_broken.bbmodel` | Decorative, door open 64° and hanging off its bottom hinge; books and a bag inside. |
| `locker_wall.bbmodel` | A 6 x 3 bank like the reference photo, with end panels, a dark kick plinth and a top cap. |
| `locker.png` | The shared texture atlas (128 x 128, 32 px per block). Every model uses it. |
| `locker_cream.png` | The same atlas with a cream door. It has the same UVs, so the interactive locker can swap to it for the off-white replacement doors in the photo. |
| `tools/gen_locker.js`, `tools/atlas.js` | The generator, which builds all of the above. Run `node tools/gen_locker.js` from this folder. It overwrites every file listed here, so hand edits made in Blockbench are lost. |
| `previews/` | Stills taken in Blockbench. |

The decorative lockers are not meant to be interactive. Their doors are posed in the model (a bone rotation), and they have no animations.

## Design

- One block is one compartment (16 x 16 x 16). Stack interactive and decorative lockers side by side to build a wall. The frame posts meet their neighbours, so the gaps between doors line up into a grid.
- Doors face north (-Z), Blockbench's front. Seen from the front, the lock is on the left and the hinges are on the right. Doors swing out toward the viewer, counter-clockwise seen from above.
- In `locker_wall.bbmodel`, the closed cells are the interactive locker model (grey, or with the cream door) and the open cells are the decorative variants. It doubles as a layout guide for building the wall in-world.

## Bones (`locker.bbmodel`)

| bone | pivot | moves |
|---|---|---|
| `locker` | 0, 0, 0 | root; squashes and jolts on the slam |
| `body` | 0, 0, 0 | the static shell: posts, roof, floor, back, hinge knuckles, coat hook |
| `door` | -7, 8, -7.6 | swings on the hinge line |
| `lock` | 4.5, 7.5, -7.8 | the key cylinder; turns on Z |

## Animations

All keys are linear and sampled every 0.05 s (one game tick) from easing and spring curves in the script. Blockbench applies Bedrock animation rotations with Y flipped relative to a bone's own rotation, so the door opens with negative Y in the animations but positive Y in the posed decorative models. `OPEN_SIGN_ANIM` and `OPEN_SIGN_POSE` in the script handle this.

| animation | length | loop | what happens |
|---|---|---|---|
| `animation.locker.open` | 0.9 s | hold | The key turns and overshoots. The door is pushed in a hair to free the latch, pops ajar, pauses a beat, then is flung open. It overshoots to about 127° and settles at 116°, past square, so the door face still shows from the front. The key springs back. |
| `animation.locker.open_idle` | 4 s | loop | Hanging open, the door drifts about 2° as if in a draft. |
| `animation.locker.close` | 0.8 s | hold | The door is pulled a little wider (wind-up), accelerates shut and slams. It bounces off the frame twice, the cabinet squashes and jolts back, and the key rattles. |
| `animation.locker.locked` | 0.7 s | once | Trying a locked door: the key jams a quarter turn and is forced twice, the door rattles in its frame, and the key snaps back. |

Suggested state flow for the menu: `open`, then `open_idle` while the menu is up, then `close` when it shuts. Play `locked` if the player can't open it.

## Contents of the interactive locker

A shelf splits the compartment in two.

- **Above the shelf**, after the reference photo: four standing textbooks (green, purple, orange, red) against the hinge-side wall, and a navy school bag hanging on the coat hook by its handle, with a brass clasp and a pink charm.
- **Below the shelf:**
  - A ninja headband tied in a loop, with its steel plate facing out. The engraved mark is generic.
  - A shuriken thrown into the floor, stuck upright behind the manga.
  - A manga volume lying cover-up, with the title band at the back so the cover reads upright when it tilts toward you. The cover is original: a loud psychic-aura style with no real title, logo or character.

Each item is its own bone. These are the ones for the interaction code to hit-test and animate:

| item bone | glow bone | sparkle bone | hover motion |
|---|---|---|---|
| `item_books` | `books_glow` | `books_sparkles` | lifts 0.9 and leans toward the viewer |
| `item_bag` | `bag_glow` | `bag_sparkles` | lifts off the hook and swings |
| `item_headband` | `headband_glow` | `headband_sparkles` | rises 1.8 and tilts its plate toward the viewer |
| `item_shuriken` | `shuriken_glow` | `shuriken_sparkles` | pops out of the floor toward the viewer and spins |
| `item_manga` | `manga_glow` | `manga_sparkles` | rises 2 and tilts its cover toward the viewer |

## Hover effect

Each item has a glow shell: an inflated copy of each of its cubes, textured with a white rim that is brighter at the edges and nearly clear in the middle. The item stays readable inside its outline. The shuriken's shell is star-shaped. Three sparkles orbit each item.

Each item has four animations. Run each item on its own GeckoLib controller, separate from the door's, so the five hovers and the door never fight over bones:

| animation | loop | what happens |
|---|---|---|
| `animation.locker.<item>.rest` | loop | The idle state. It holds the glow at scale 0 (hidden) and the item at rest. |
| `animation.locker.<item>.hover_start` | once (0.35 s) | A tiny dip (anticipation), then the item lifts off with an overshoot. The glow blooms in, overshooting too, and the sparkles spin up. |
| `animation.locker.<item>.hover` | loop (2 s) | The item floats and bobs. The glow breathes, and the sparkles orbit and twinkle. |
| `animation.locker.<item>.hover_end` | once (0.3 s) | The item drops back with a small bump on landing and the glow fades out. The shuriken re-sticks with a quiver. |

On mouse enter, play `hover_start` then `hover`. On mouse leave, play `hover_end` then `rest`. The item keys are the same names as in the table: `books`, `bag`, `headband`, `shuriken`, `manga`.

- **Full-bright glow:** `locker_glowmask.png` contains only the glow and sparkle pixels. GeckoLib's `AutoGlowingGeoLayer` picks it up by name (`<texture>_glowmask.png`) and renders those parts full-bright.
- **Render type:** use a translucent render type for the locker (for example `entityTranslucent`) so the shell's soft alpha shows.
- **In Blockbench:** the glow shells are visible at rest, because no `rest` clip is playing. Hide the `*_glow` bones in the outliner to see the items plainly.

## Blockbench caution

Blockbench can write its open copy back to the `.bbmodel` when you close the tab, even after choosing Discard. If you hid bones or changed anything, it saves those changes. Rerun the generator after closing a tab if the file must match the script.

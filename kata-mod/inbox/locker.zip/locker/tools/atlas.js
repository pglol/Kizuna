// The shared 128x128 texture atlas (64x64 UV units, 2 px per unit = 32 px per block):
// locker shell, grey and cream doors, and the props that sit in open lockers.
// Everything is painted here in code; `R` holds each region and its UVs.
const zlib = require('zlib');

const PX = 2;            // texture pixels per model unit
const ATLAS = 64;        // atlas size in UV units
const W = ATLAS * PX, H = ATLAS * PX;

// ---------------------------------------------------------------- palette
const C = {
  hi:    [222, 226, 228],
  lite:  [205, 209, 212],
  base:  [189, 194, 198],
  mid:   [170, 175, 180],
  sh:    [146, 151, 157],
  dk:    [112, 117, 123],
  dkr:   [ 80,  84,  90],
  black: [ 40,  42,  47],
  in1:   [118, 122, 128],
  in2:   [ 92,  96, 102],
  in3:   [ 66,  69,  75],
  in4:   [ 48,  50,  55],
  card:  [238, 234, 220],
  card2: [214, 209, 192],
  ink:   [128, 132, 150],
  chr:   [232, 235, 238],
  chr2:  [196, 200, 205],
  chr3:  [140, 145, 151],
  brass: [205, 178, 104],
  brass2:[150, 124,  62],
  // props
  white: [240, 240, 236],
  white2:[214, 214, 210],
  white3:[184, 186, 184],
  green: [ 76, 158,  98],
  green2:[ 52, 118,  72],
  navy:  [ 46,  56,  92],
  navy2: [ 32,  38,  66],
  bookR: [178,  58,  56],
  bookB: [ 58,  96, 160],
  bookY: [222, 180,  70],
  paper: [236, 230, 210],
  towel: [150, 196, 222],
  towel2:[118, 168, 200],
  tag:   [ 92, 160, 220],
  tag2:  [ 66, 128, 190],
  bag:   [232, 236, 240],
  bag2:  [206, 212, 220],
  bag3:  [176, 184, 196],
  string:[ 70,  64,  58],
  rubber:[ 58,  60,  64],
  kick:  [ 92,  96, 100],
};
// replacement doors in the reference are an off-white cream
const CREAM = {
  hi:   [240, 235, 222],
  lite: [228, 222, 206],
  base: [214, 207, 189],
  mid:  [196, 189, 170],
  sh:   [170, 163, 145],
  dk:   [132, 126, 110],
};

// ---------------------------------------------------------------- canvas
let img = Buffer.alloc(W * H * 4);
let seed = 1337;
const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
function hash(x, y) { let h = (x * 374761393 + y * 668265263) ^ 0x5bd1e995; h = (h ^ (h >>> 13)) * 1274126177; return ((h ^ (h >>> 16)) >>> 0) / 4294967295; }
function set(x, y, c, a = 255) {
  if (x < 0 || y < 0 || x >= W || y >= H) return;
  const i = (y * W + x) * 4; img[i] = c[0]; img[i + 1] = c[1]; img[i + 2] = c[2]; img[i + 3] = a;
}
function get(x, y) { const i = (y * W + x) * 4; return [img[i], img[i + 1], img[i + 2]]; }
const shade = (c, d) => c.map(v => Math.max(0, Math.min(255, Math.round(v + d))));
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
// painted steel: fine grain noise plus the odd scuff
function steel(c, x, y, amt = 4) {
  const n = (hash(x, y) - 0.5) * 2 * amt;
  const scuff = hash(x * 7 + 3, y * 13 + 1) > 0.985 ? -10 : 0;
  return shade(c, n + scuff);
}
const cloth = (c, x, y, amt = 6) => shade(c, (hash(x * 3 + 1, y * 5 + 2) - 0.5) * 2 * amt);
// region helpers in PIXELS relative to a region origin given in UNITS
function region(ux, uy, uw, uh) {
  const ox = ux * PX, oy = uy * PX, w = uw * PX, h = uh * PX;
  return {
    ux, uy, uw, uh, w, h, ox, oy,
    px(x, y, c, a) { if (x >= 0 && y >= 0 && x < w && y < h) set(ox + x, oy + y, c, a); },
    get(x, y) { return get(ox + x, oy + y); },
    fill(x, y, fw, fh, fn) { for (let j = y; j < y + fh; j++) for (let i = x; i < x + fw; i++) this.px(i, j, typeof fn === 'function' ? fn(i, j) : fn); },
    uv(x1 = 0, y1 = 0, x2 = uw, y2 = uh) { return [ux + x1, uy + y1, ux + x2, uy + y2]; },
  };
}

// ---------------------------------------------------------------- atlas layout (units)
const R = {
  doorFront: region(0, 0, 14, 14),
  doorBack:  region(14, 0, 14, 14),
  doorEdgeV: region(28, 0, 1, 14),
  frameV:    region(29, 0, 1, 16),
  innerSide: region(30, 0, 15, 16),   // painted as seen from inside: front of locker on the RIGHT
  innerBack: region(45, 0, 16, 16),
  doorEdgeH: region(0, 14, 14, 1),
  frameTop:  region(0, 15, 14, 1),
  frameBot:  region(0, 16, 14, 1),
  floor:     region(0, 17, 14, 15),   // front of locker at the BOTTOM of the region
  ceil:      region(14, 17, 14, 15),  // front of locker at the BOTTOM of the region
  outerSide: region(28, 17, 15, 16),  // front of locker on the RIGHT
  plain:     region(43, 17, 16, 16),
  backOuter: region(0, 33, 16, 16),
  label:     region(16, 33, 4, 2.5),
  bezel:     region(21, 33, 3, 3),
  cyl:       region(24, 33, 1.5, 1.5),
  swatch:    region(26, 33, 16, 1),     // 1x1-unit solid swatches
  knuckle:   region(26, 35, 1, 3),
  // cream replacement door
  doorFrontCream: region(0, 49, 14, 14),
  doorBackCream:  region(14, 49, 14, 14),
  // wall bank parts
  kick:      region(42, 33, 16, 2),     // plinth front: dark, scuffed by shoes
  endFront:  region(59, 17, 2, 16),     // front edge of the bank's end panels
  // props: indoor shoes (uwabaki, white + green), outdoor sneakers (navy + white)
  shoeW_up:   region(28, 35, 2.5, 5.5),
  shoeW_side: region(31, 35, 5.5, 1.5), // toe on the RIGHT
  shoeW_toe:  region(31, 37, 2.5, 1.5),
  shoeW_heel: region(34, 37, 2.5, 1.5),
  shoeN_up:   region(37, 35, 2.5, 5.5),
  shoeN_side: region(40, 35, 5.5, 1.5),
  shoeN_toe:  region(40, 37, 2.5, 1.5),
  shoeN_heel: region(43, 37, 2.5, 1.5),
  // convenience-store plastic bag
  bag_front: region(46, 37, 4, 3),
  bag_side:  region(50, 37, 3, 3),
  bag_top:   region(53, 37, 4, 3),
  // drawstring pouch (kinchaku)
  kin_front: region(28, 41, 3.5, 4),
  kin_side:  region(32, 41, 2, 4),
  kin_top:   region(34, 41, 3.5, 2),
  // books
  bookR_top: region(38, 41, 5, 3.5),
  bookB_top: region(43, 41, 5, 3.5),
  bookY_top: region(48, 41, 5, 3.5),
  pages:     region(53, 41, 5, 1),
  // towel and paper tag
  towel:     region(28, 46, 4, 6),
  tag:       region(33, 46, 1.5, 2),
  // interactive locker contents
  spine0: region(35, 46, 1.5, 6), spine1: region(36.5, 46, 1.5, 6), spine2: region(38, 46, 1.5, 6), spine3: region(39.5, 46, 1.5, 6),
  cover0: region(41, 46, 4, 6),   cover1: region(45, 46, 4, 6),     cover2: region(49, 46, 4, 6),   cover3: region(53, 46, 4, 6),
  sbag_front: region(57, 46, 4.5, 4), sbag_side: region(61.5, 46, 2.5, 4), sbag_top: region(57, 50, 4.5, 2.5),
  manga_front: region(58, 33, 3.5, 5), manga_back: region(58, 38, 3.5, 5),
  hb_plate: region(28, 52, 3, 1.5), hb_band: region(31, 52, 2, 1.5),
  shuriken: region(35, 52, 4.5, 4.5),
  glow: region(40, 52, 4, 4),            // white rim glow, semi-transparent
  sparkle: region(44, 52, 1.5, 1.5),
  shurikenGlow: region(46, 52, 4.5, 4.5),
  clear: region(51, 52, 1, 1),           // left fully transparent
};
const SWATCH_NAMES = ['chr', 'chr2', 'chr3', 'mid', 'sh', 'dk', 'card2', 'base', 'in2', 'lite', 'string', 'bookR', 'bookB', 'bookY', 'white', 'green'];
const SW = {}; // swatch name -> uv for tiny faces
SWATCH_NAMES.forEach((k, i) => {
  R.swatch.fill(i * PX, 0, PX, PX, C[k]);
  SW[k] = [R.swatch.ux + i + 0.25, R.swatch.uy + 0.25, R.swatch.ux + i + 0.75, R.swatch.uy + 0.75];
});

// ---------------------------------------------------------------- locker shell + doors
// Door front, 28x28 px, seen from the front: lock side on the left, hinge side on the right.
function doorFront(r, P) {
  const w = r.w, h = r.h;
  r.fill(0, 0, w, h, (x, y) => steel(mix(P.base, P.lite, 1 - y / h * 0.6), x, y));
  // folded edge: light top/left, dark bottom/right, softer inner ring
  for (let i = 0; i < w; i++) { r.px(i, 0, P.hi); r.px(i, h - 1, P.sh); r.px(i, 1, shade(r.get(i, 1), 8)); r.px(i, h - 2, shade(r.get(i, h - 2), -10)); }
  for (let j = 0; j < h; j++) { r.px(0, j, P.hi); r.px(w - 1, j, P.sh); r.px(1, j, shade(r.get(1, j), 8)); r.px(w - 2, j, shade(r.get(w - 2, j), -10)); }
  r.px(w - 1, 0, P.mid); r.px(0, h - 1, P.mid);
  // pressed louvres: a lit lip over a dark slot over a soft shadow
  const louvre = (y) => {
    const x0 = 10, x1 = 20;
    for (let x = x0; x < x1; x++) {
      const end = x === x0 || x === x1 - 1;
      r.px(x, y, end ? P.lite : P.hi);
      r.px(x, y + 1, end ? P.dk : C.black);
      r.px(x, y + 2, end ? P.mid : P.sh);
    }
    r.px(x0 - 1, y + 1, P.mid); r.px(x1, y + 1, P.lite);
  };
  [3, 6, 9].forEach(louvre);
  [17, 20, 23].forEach(louvre);
  // drop shadows of the label (px 1..8 x 3..7) and the lock bezel (px 2..7 x 12..17)
  r.fill(2, 8, 8, 1, (x, y) => shade(r.get(x, y), -18));
  r.fill(9, 4, 1, 5, (x, y) => shade(r.get(x, y), -14));
  r.fill(3, 18, 6, 1, (x, y) => shade(r.get(x, y), -18));
  r.fill(8, 13, 1, 5, (x, y) => shade(r.get(x, y), -14));
  // finger wear around the lock and a couple of scratches
  for (let k = 0; k < 14; k++) { const x = 1 + Math.floor(rnd() * 9), y = 10 + Math.floor(rnd() * 10); r.px(x, y, shade(r.get(x, y), -6)); }
  [[14, 14], [15, 14], [16, 15]].forEach(([x, y]) => r.px(x, y, shade(r.get(x, y), 12)));
}
// Door back (inside skin), seen from inside: hinge side on the left.
function doorBack(r, P) {
  const w = r.w, h = r.h;
  r.fill(0, 0, w, h, (x, y) => steel(P.mid, x, y, 3));
  // raised stiffener channel all round, recessed centre panel
  for (let i = 0; i < w; i++) { r.px(i, 0, P.lite); r.px(i, h - 1, P.dk); }
  for (let j = 0; j < h; j++) { r.px(0, j, P.lite); r.px(w - 1, j, P.dk); }
  for (let j = 3; j < h - 3; j++) for (let i = 3; i < w - 3; i++) r.px(i, j, steel(P.sh, i, j, 3));
  for (let i = 3; i < w - 3; i++) { r.px(i, 3, P.dk); r.px(i, h - 4, P.lite); }
  for (let j = 3; j < h - 3; j++) { r.px(3, j, P.dk); r.px(w - 4, j, P.lite); }
  // louvre openings seen from behind (same rows as the front, mirrored)
  const slot = (y) => { for (let x = 8; x < 18; x++) { r.px(x, y, C.dkr); r.px(x, y + 1, C.black); r.px(x, y + 2, P.mid); } };
  [3, 6, 9, 17, 20, 23].forEach(slot);
  // back of the lock: cam plate on the right (lock side)
  r.fill(19, 11, 8, 8, (x, y) => steel(C.chr3, x, y, 3));
  r.fill(20, 12, 6, 6, C.chr2);
  r.fill(22, 14, 2, 2, C.dkr); r.fill(21, 15, 4, 1, C.chr3);
  // small coat hook boss near the top on the hinge side
  r.fill(5, 5, 2, 2, C.chr2); r.px(6, 6, C.chr3);
}
doorFront(R.doorFront, C);
doorBack(R.doorBack, C);
doorFront(R.doorFrontCream, CREAM);
doorBack(R.doorBackCream, CREAM);

const edgeFill = (r, c) => r.fill(0, 0, r.w, r.h, (x, y) => steel(c, x, y, 3));
edgeFill(R.doorEdgeV, C.sh);
edgeFill(R.doorEdgeH, C.sh);

// front of the frame posts (1 unit wide): light face with a dark gap line on the door side
(function frame() {
  const v = R.frameV; v.fill(0, 0, v.w, v.h, (x, y) => steel(C.lite, x, y, 3));
  for (let j = 0; j < v.h; j++) { v.px(0, j, C.hi); v.px(1, j, C.mid); }
  const t = R.frameTop; t.fill(0, 0, t.w, t.h, (x, y) => steel(C.lite, x, y, 3));
  for (let i = 0; i < t.w; i++) { t.px(i, 0, C.hi); t.px(i, 1, C.mid); }
  const b = R.frameBot; b.fill(0, 0, b.w, b.h, (x, y) => steel(C.base, x, y, 3));
  for (let i = 0; i < b.w; i++) { b.px(i, 0, C.lite); b.px(i, 1, C.sh); }
})();

// interior: darker toward the back, a lit band where light falls in at the front
(function interior() {
  const s = R.innerSide;                       // x: 0 = back, w-1 = front
  s.fill(0, 0, s.w, s.h, (x, y) => {
    const t = x / (s.w - 1);
    let c = x === s.w - 1 ? C.in4 : t > 0.9 ? C.in1 : mix(C.in4, C.in2, Math.pow(t, 1.4));
    if (y < 3 || y > s.h - 4) c = shade(c, -10);   // corners darker
    return steel(c, x, y, 3);
  });
  // a row of vent holes near the top
  for (let i = 0; i < 5; i++) { const x = 6 + i * 4; s.px(x, 5, C.black); s.px(x + 1, 5, C.black); s.px(x, 6, shade(C.in2, 8)); s.px(x + 1, 6, shade(C.in2, 8)); }
  const b = R.innerBack;
  b.fill(0, 0, b.w, b.h, (x, y) => {
    const ex = Math.min(x, b.w - 1 - x), ey = Math.min(y, b.h - 1 - y);
    return steel(shade(C.in4, Math.min(Math.min(ex, ey), 8) * 1.2), x, y, 3);
  });
  // fold seam across the back panel
  for (let i = 2; i < b.w - 2; i++) { b.px(i, 20, shade(C.in4, -14)); b.px(i, 21, shade(C.in4, 10)); }
  const f = R.floor;                            // y: 0 = back, h-1 = front
  f.fill(0, 0, f.w, f.h, (x, y) => {
    let c = mix(C.in3, C.in1, Math.pow(y / (f.h - 1), 1.3));
    if (x < 2 || x > f.w - 3) c = shade(c, -10);
    return steel(c, x, y, 3);
  });
  // ribbed floor mat lines
  for (let y = 4; y < f.h - 2; y += 4) for (let x = 2; x < f.w - 2; x++) f.px(x, y, shade(f.get(x, y), -10));
  const c = R.ceil;
  c.fill(0, 0, c.w, c.h, (x, y) => {
    let col = mix(C.in4, C.in2, Math.pow(y / (c.h - 1), 1.6));
    if (x < 2 || x > c.w - 3) col = shade(col, -8);
    return steel(col, x, y, 3);
  });
  // the half unit in front of the recessed door is a shadow gap all round the door
  for (let x = 0; x < f.w; x++) { f.px(x, f.h - 1, C.in4); c.px(x, c.h - 1, C.in4); }
})();

// outside skin
(function outside() {
  const s = R.outerSide;                       // x: 0 = back, w-1 = front
  s.fill(0, 0, s.w, s.h, (x, y) => steel(mix(C.base, C.mid, y / s.h * 0.5), x, y, 3));
  for (let j = 0; j < s.h; j++) { s.px(s.w - 1, j, C.lite); s.px(0, j, C.sh); }
  for (let i = 0; i < s.w; i++) { s.px(i, 0, C.lite); s.px(i, s.h - 1, C.sh); }
  // pressed rib along the side
  for (let i = 3; i < s.w - 3; i++) { s.px(i, 9, C.lite); s.px(i, 10, C.sh); s.px(i, 21, C.lite); s.px(i, 22, C.sh); }
  const p = R.plain;
  p.fill(0, 0, p.w, p.h, (x, y) => steel(C.mid, x, y, 3));
  const b = R.backOuter;
  b.fill(0, 0, b.w, b.h, (x, y) => steel(C.sh, x, y, 3));
  for (let i = 0; i < b.w; i++) { b.px(i, 0, C.mid); b.px(i, b.h - 1, C.dk); }
  // plinth kick plate: dark, with black shoe scuffs low down
  const k = R.kick;
  k.fill(0, 0, k.w, k.h, (x, y) => steel(C.kick, x, y, 4));
  for (let i = 0; i < k.w; i++) { k.px(i, 0, shade(C.kick, 14)); k.px(i, k.h - 1, shade(C.kick, -16)); }
  for (let n = 0; n < 5; n++) { const x = 1 + Math.floor(rnd() * (k.w - 4)), y = 1 + Math.floor(rnd() * 2); k.px(x, y, shade(C.kick, -18)); k.px(x + 1, y, shade(C.kick, -12)); }
  // end panel front edge: a lit bevel
  const e = R.endFront;
  e.fill(0, 0, e.w, e.h, (x, y) => steel(C.lite, x, y, 3));
  for (let j = 0; j < e.h; j++) { e.px(0, j, C.hi); e.px(e.w - 1, j, C.mid); }
})();

// label holder: chrome frame with a cream name card
(function label() {
  const r = R.label, w = r.w, h = r.h; // 8x5
  r.fill(0, 0, w, h, C.chr2);
  for (let i = 0; i < w; i++) { r.px(i, 0, C.chr); r.px(i, h - 1, C.chr3); }
  for (let j = 0; j < h; j++) { r.px(0, j, C.chr); r.px(w - 1, j, C.chr3); }
  r.fill(1, 1, w - 2, h - 2, C.card);
  r.fill(1, 1, w - 2, 1, (x) => (x === 1 || x === w - 2 ? C.card2 : C.card)); // slot lip shadow
  [1, 2, 4, 5].forEach((x) => r.px(x, 2, C.ink));   // a name in marker
  [2, 3, 5].forEach((x) => r.px(x, 3, C.ink));      // and a number
  r.px(6, 3, C.card2);
})();

// lock: round chrome bezel (corners painted door-grey so it reads round) and a
// brass cylinder with a keyway that turns with it
(function lock() {
  const b = R.bezel, w = b.w; // 6x6
  const door = R.doorFront.get(3, 14);
  b.fill(0, 0, w, w, C.chr2);
  for (let i = 1; i < w - 1; i++) { b.px(i, 0, C.chr); b.px(0, i, C.chr); b.px(i, w - 1, C.chr3); b.px(w - 1, i, C.chr3); }
  [[0, 0], [w - 1, 0], [0, w - 1], [w - 1, w - 1]].forEach(([x, y]) => b.px(x, y, door));
  b.px(1, 1, C.chr); b.px(w - 2, w - 2, C.chr3);
  const c = R.cyl; // 3x3
  c.fill(0, 0, 3, 3, C.brass);
  c.px(0, 0, C.chr); c.px(2, 0, C.chr2); c.px(0, 2, C.chr2); c.px(2, 2, C.chr3);
  c.px(1, 0, C.black); c.px(1, 1, C.black); c.px(1, 2, C.brass2);   // keyway: a slot from the top
  const k = R.knuckle; k.fill(0, 0, k.w, k.h, (x) => (x === 0 ? C.chr : C.chr3));
  for (let x = 0; x < k.w; x++) { k.px(x, 0, C.chr2); k.px(x, k.h - 1, C.chr3); }
})();

// ---------------------------------------------------------------- props
// shoes: up face has the toe at the TOP (north), side faces have the toe on the RIGHT
function shoe(up, side, toe, heel, S) {
  // up: 5 x 11 px
  up.fill(0, 0, up.w, up.h, (x, y) => cloth(S.body, x, y, 5));
  up.fill(0, 0, up.w, 3, (x, y) => cloth(S.toe, x, y, 4));
  up.px(0, 0, S.toe2); up.px(up.w - 1, 0, S.toe2);
  up.fill(0, 3, up.w, 1, S.band);                         // elastic band / laces
  if (S.laces) { up.px(1, 4, S.band); up.px(3, 4, S.band); up.px(2, 5, S.band); }
  up.fill(1, 6, 3, 4, C.in3); up.fill(1, 6, 3, 1, C.in2);  // the opening
  up.fill(0, 10, up.w, 1, S.toe2);                        // heel tab
  if (S.name) { up.px(2, 8, S.name); }
  // side: 11 x 3 px
  side.fill(0, 0, side.w, side.h, (x, y) => cloth(S.body, x, y, 5));
  side.fill(0, 2, side.w, 1, S.sole);
  side.fill(side.w - 3, 0, 3, 3, (x, y) => cloth(S.toe, x, y, 4));
  side.px(side.w - 3, 0, S.body);
  side.fill(0, 0, 1, 3, S.toe2);
  side.fill(3, 0, 4, 1, shade(S.body, -14));               // collar dips lower at the opening
  toe.fill(0, 0, toe.w, toe.h, (x, y) => cloth(S.toe, x, y, 4));
  toe.fill(0, toe.h - 1, toe.w, 1, S.sole);
  heel.fill(0, 0, heel.w, heel.h, (x, y) => cloth(S.body, x, y, 5));
  heel.fill(0, heel.h - 1, heel.w, 1, S.sole);
  heel.fill(2, 0, 1, 2, S.toe2);
}
shoe(R.shoeW_up, R.shoeW_side, R.shoeW_toe, R.shoeW_heel,
  { body: C.white, toe: C.green, toe2: C.green2, band: C.white3, sole: C.green2, name: C.ink });
shoe(R.shoeN_up, R.shoeN_side, R.shoeN_toe, R.shoeN_heel,
  { body: C.navy, toe: C.white, toe2: C.white2, band: C.white, sole: C.white2, laces: true });

// plastic bag: crumpled white with a faint printed stripe
(function bag() {
  const crumple = (r) => r.fill(0, 0, r.w, r.h, (x, y) => {
    const v = hash(x * 5 + r.ox, y * 3 + r.oy);
    return v > 0.75 ? C.bag3 : v > 0.4 ? C.bag2 : C.bag;
  });
  crumple(R.bag_front); crumple(R.bag_side); crumple(R.bag_top);
  R.bag_front.fill(1, 2, 6, 1, (x) => (x % 2 ? C.tag : C.tag2));
  R.bag_top.fill(3, 2, 2, 2, C.bag3); R.bag_top.px(3, 2, C.white3);   // knotted handles
})();

// drawstring pouch: navy with little white dots, gathered at the top
(function kinchaku() {
  const dots = (r) => r.fill(0, 0, r.w, r.h, (x, y) => ((x + (y % 4 < 2 ? 0 : 2)) % 4 === 0 && y % 2 === 0 ? C.white2 : cloth(C.navy, x, y, 6)));
  dots(R.kin_front); dots(R.kin_side);
  for (const r of [R.kin_front, R.kin_side]) { r.fill(0, 0, r.w, 2, (x) => (x % 2 ? C.navy2 : C.navy)); }
  const t = R.kin_top; t.fill(0, 0, t.w, t.h, (x, y) => cloth(C.navy, x, y, 6));
  t.fill(2, 1, 3, 2, C.navy2); t.px(3, 1, C.string);
})();

// books: a cover with a title band, cream page edges
(function books() {
  const cover = (r, c) => {
    r.fill(0, 0, r.w, r.h, (x, y) => cloth(c, x, y, 4));
    r.fill(0, 0, 1, r.h, shade(c, -24));                  // spine side
    r.fill(2, 2, r.w - 4, 2, C.paper); r.fill(3, 2, 3, 1, shade(C.ink, -20));
    r.fill(2, r.h - 2, 3, 1, shade(c, 30));
  };
  cover(R.bookR_top, C.bookR); cover(R.bookB_top, C.bookB); cover(R.bookY_top, C.bookY);
  R.pages.fill(0, 0, R.pages.w, R.pages.h, (x, y) => (y === 0 ? C.paper : shade(C.paper, -18 + (x % 2) * 6)));
})();

// towel: light blue terry with two white stripes
(function towel() {
  const r = R.towel;
  r.fill(0, 0, r.w, r.h, (x, y) => cloth(C.towel, x, y, 10));
  for (const y of [2, 3, r.h - 4, r.h - 3]) r.fill(0, y, r.w, 1, (x) => cloth(C.white, x, y, 6));
  r.fill(0, r.h - 1, r.w, 1, (x) => (x % 2 ? C.towel2 : C.towel));   // fringe
})();

// paper tag: blue card with a punched hole and a scribble
(function tag() {
  const r = R.tag; // 3x4
  r.fill(0, 0, 3, 4, C.tag);
  r.px(1, 0, C.white); r.px(0, 3, C.tag2); r.px(2, 3, C.tag2);
  r.px(0, 2, C.white2); r.px(1, 2, C.white2);
})();

// ---------------------------------------------------------------- interactive locker contents
// textbooks, standing: spines (3 x 12 px) face the door, covers (8 x 12 px) face the sides
const BOOKS = [
  { c: [ 46, 138,  86], band: [236, 222, 150], ink: [250, 250, 240] },   // literature, green
  { c: [ 98,  78, 168], band: [246, 206,  72], ink: [250, 236, 140] },   // science, purple
  { c: [230, 120,  62], band: [ 60,  52,  60], ink: [252, 240, 220] },   // maths, orange
  { c: [168,  44,  52], band: [236, 230, 214], ink: [236, 230, 214] },   // history, red
];
BOOKS.forEach((b, i) => {
  const s = R['spine' + i], v = R['cover' + i];
  s.fill(0, 0, s.w, s.h, (x, y) => cloth(b.c, x, y, 4));
  s.fill(0, 0, s.w, 1, shade(b.c, -30)); s.fill(0, s.h - 1, s.w, 1, shade(b.c, -30));
  s.fill(0, 1, 1, s.h - 2, shade(b.c, 18));                   // rounded spine highlight
  s.fill(0, 2, s.w, 2, b.band);                                // label band
  [5, 6, 8, 9].forEach((y) => s.px(1, y, b.ink));              // title running down the spine
  s.px(1, s.h - 3, b.band);                                    // publisher mark
  v.fill(0, 0, v.w, v.h, (x, y) => cloth(b.c, x, y, 4));
  v.fill(1, 1, v.w - 2, 3, b.band);
  [2, 3, 5].forEach((x) => v.px(x, 2, shade(b.band, -90)));
  v.fill(1, 6, v.w - 2, 1, shade(b.c, 22)); v.fill(v.w - 1, 0, 1, v.h, shade(b.c, -26));
  if (i === 1) { v.px(3, 8, b.ink); v.px(4, 9, b.ink); v.px(5, 8, b.ink); }   // a little atom doodle
});

// school bag: navy leather with a flap, a brass clasp and a pink charm
(function schoolBag() {
  const leather = (r) => r.fill(0, 0, r.w, r.h, (x, y) => cloth(C.navy2, x, y, 5));
  const f = R.sbag_front; leather(f);
  f.fill(0, 0, f.w, 3, (x, y) => cloth(C.navy, x, y, 4));     // flap
  f.fill(0, 3, f.w, 1, shade(C.navy2, -12));
  f.fill(3, 2, 3, 2, C.brass); f.px(4, 3, C.brass2);         // clasp
  f.fill(1, 5, f.w - 2, 1, shade(C.navy2, 14));               // stitched pocket edge
  f.px(7, 5, [236, 150, 190]); f.px(7, 6, [236, 150, 190]); f.px(8, 6, [250, 196, 214]);   // charm
  const s = R.sbag_side; leather(s); s.fill(0, 0, s.w, 1, C.navy);
  const t = R.sbag_top; leather(t); t.fill(2, 1, 5, 1, C.string); t.fill(2, 3, 5, 1, C.string);   // handle
})();

// manga volume: an original cover in a loud, scribbly "psychic" style. Bold title band,
// clashing aura rings, a volume number. (No real title, logo or character.)
(function manga() {
  const f = R.manga_front; // 7 x 10
  const ring = [[255, 92, 170], [120, 236, 96], [96, 214, 250], [168, 92, 236], [255, 226, 70]];
  const cx = 3.5, cy = 6.2;
  f.fill(0, 0, f.w, f.h, (x, y) => ring[Math.floor(Math.hypot(x + 0.5 - cx, (y + 0.5 - cy) * 1.15) + (x + y) % 2 * 0.4) % ring.length]);
  f.fill(0, 0, f.w, 3, [24, 22, 30]);                         // title band
  [[1, 1], [2, 1], [4, 1], [5, 1], [1, 2], [3, 2], [5, 2]].forEach(([x, y]) => f.px(x, y, [250, 250, 250]));
  f.px(6, 2, [255, 92, 170]);
  f.fill(2, 5, 3, 3, [250, 250, 250]); f.px(3, 6, [24, 22, 30]);   // a white burst at the heart of the aura
  f.fill(0, f.h - 1, f.w, 1, [250, 250, 250]); f.px(5, f.h - 1, [24, 22, 30]);   // volume number
  f.fill(0, 0, 1, f.h, (x, y) => shade(f.get(0, y), -40));    // spine edge
  const b = R.manga_back;
  b.fill(0, 0, b.w, b.h, (x, y) => cloth([255, 92, 170], x, y, 6));
  b.fill(1, 2, 5, 3, [250, 250, 250]); [1, 3, 4].forEach((y) => b.fill(2, y + 1, 3, 1, [200, 70, 140]));
  b.fill(4, 7, 2, 2, [250, 250, 250]); b.px(4, 8, [24, 22, 30]);   // barcode
})();

// ninja headband: a navy cloth band and a steel plate with an engraved (generic) mark
(function headband() {
  const p = R.hb_plate; // 6 x 3
  p.fill(0, 0, p.w, p.h, [176, 182, 190]);
  p.fill(0, 0, p.w, 1, [222, 228, 234]); p.fill(0, p.h - 1, p.w, 1, [118, 124, 132]);
  p.px(0, 1, [200, 206, 212]); p.px(p.w - 1, 1, [140, 146, 154]);
  p.px(2, 1, [70, 74, 82]); p.px(3, 1, [70, 74, 82]); p.px(1, 2, [96, 100, 108]); p.px(4, 2, [96, 100, 108]);   // a little peak
  const b = R.hb_band; // 4 x 3
  b.fill(0, 0, b.w, b.h, (x, y) => cloth([38, 48, 86], x, y, 6));
  b.fill(0, 0, b.w, 1, (x) => (x % 2 ? [58, 70, 118] : [38, 48, 86]));    // stitched edge
})();

// shuriken: a four-blade pinwheel star in gunmetal with a punched centre, 9 x 9 px,
// transparent around it. Each blade has one straight edge (lit) and one swept edge.
(function shuriken() {
  const r = R.shuriken, N = 9, c = 4;
  // blade k points along (ax, ay); its swept side is along (bx, by)
  const blades = [[0, -1, 1, 0], [1, 0, 0, 1], [0, 1, -1, 0], [-1, 0, 0, -1]];
  const where = (x, y) => {
    const dx = x - c, dy = y - c;
    if (Math.abs(dx) <= 1 && Math.abs(dy) <= 1) return 'hub';
    for (const [ax, ay, bx, by] of blades) {
      const u = dx * ax + dy * ay, v = dx * bx + dy * by;
      if (u >= 1 && u <= 4 && v >= 0 && v <= (4 - u) * 0.75) return v === 0 ? 'edge' : 'blade';
    }
    return null;
  };
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const w = where(x, y);
    if (!w) continue;
    r.px(x, y, w === 'edge' ? [176, 182, 190] : w === 'hub' ? [118, 122, 130] : (x + y) % 2 ? [88, 92, 100] : [70, 74, 82]);
  }
  r.px(c, c, [24, 26, 30]);                                   // punched centre
  r.px(c, 0, [220, 226, 234]); r.px(N - 1, c, [220, 226, 234]);   // glinting tips
  // its glow: the same star grown by a pixel, soft white
  const g = R.shurikenGlow;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    let near = false;
    for (const [i, j] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) if (x + i >= 0 && x + i < N && y + j >= 0 && y + j < N && where(x + i, y + j)) near = true;
    if (near) g.px(x, y, [255, 255, 255], where(x, y) ? 50 : 200);
  }
})();

// hover glow: white, brighter at the rim so each shell reads as a soft outline
(function glow() {
  const g = R.glow;
  for (let y = 0; y < g.h; y++) for (let x = 0; x < g.w; x++) {
    const e = Math.min(x, y, g.w - 1 - x, g.h - 1 - y);
    g.px(x, y, [255, 255, 255], e === 0 ? 210 : e === 1 ? 90 : 28);
  }
  const s = R.sparkle; // 3 x 3: a little four-point twinkle
  s.px(1, 1, [255, 255, 255], 255);
  [[1, 0], [0, 1], [2, 1], [1, 2]].forEach(([x, y]) => s.px(x, y, [255, 255, 255], 170));
})();

// ---------------------------------------------------------------- png
function crc32(buf) { let c, crc = 0xffffffff; for (let n = 0; n < buf.length; n++) { c = (crc ^ buf[n]) & 0xff; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crc = (crc >>> 8) ^ c; } return (crc ^ 0xffffffff) >>> 0; }
function chunk(type, data) { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); }
function encode(buf) {
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 6;
  const raw = Buffer.alloc((W * 4 + 1) * H);
  for (let y = 0; y < H; y++) { raw[y * (W * 4 + 1)] = 0; buf.copy(raw, y * (W * 4 + 1) + 1, y * W * 4, (y + 1) * W * 4); }
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}
// copy one region's pixels onto another of the same size
function blit(buf, from, to) {
  for (let y = 0; y < from.h; y++) img.copy(buf, ((to.oy + y) * W + to.ox) * 4, ((from.oy + y) * W + from.ox) * 4, ((from.oy + y) * W + from.ox + from.w) * 4);
}
// main atlas, plus a cream-door variant of it with the same UVs (for the interactive locker)
function pngs() {
  const main = encode(img);
  const creamBuf = Buffer.from(img);
  blit(creamBuf, R.doorFrontCream, R.doorFront);
  blit(creamBuf, R.doorBackCream, R.doorBack);
  // glowmask (GeckoLib's AutoGlowingGeoLayer convention: <texture>_glowmask.png):
  // only the glow shells and sparkles, so they render full-bright
  const maskBuf = Buffer.alloc(W * H * 4);
  for (const r of [R.glow, R.sparkle, R.shurikenGlow]) blit(maskBuf, r, r);
  return { main, cream: encode(creamBuf), glowmask: encode(maskBuf) };
}

module.exports = { PX, ATLAS, W, H, C, R, SW, pngs };

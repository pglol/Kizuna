// Builds the locker set for Blockbench (Bedrock/GeckoLib format), all from one cell builder:
//   locker.bbmodel             the interactive locker, with its animations
//   locker_deco_*.bbmodel      non-interactive lockers left open with things in them
//   locker_wall.bbmodel        a bank of lockers like the reference photo
//   locker.png                 the shared texture atlas (painted in tools/atlas.js)
//   locker_cream.png           the same atlas with a cream door, for the interactive locker
// Run from the locker folder: node tools/gen_locker.js
//
// Orientation: doors face NORTH (-Z), Blockbench's front. Seen from the front the lock is
// on the left (+X) and the hinges on the right (-X), as in the references.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const A = require('./atlas');
const { R, SW, ATLAS, W, H } = A;

const OUT = path.join(__dirname, '..');
const uuid = () => crypto.randomUUID();

// Door swing signs. Blockbench applies Bedrock animation rotations with X and Y flipped
// relative to the bone rotation stored in the model, so the two need opposite signs for
// the door to swing OUT toward the viewer (counter-clockwise seen from above).
const OPEN_SIGN_ANIM = -1;
const OPEN_SIGN_POSE = 1;

// ---------------------------------------------------------------- tree helpers
// Children are element objects or groups; uuids are resolved when a model is written.
function cube(name, from, to, faces, extra = {}) {
  const f = {};
  for (const k of ['north', 'east', 'south', 'west', 'up', 'down']) f[k] = { uv: faces[k] || faces.rest, texture: 0 };
  const e = {
    name, box_uv: false, rescale: false, locked: false, light_emission: 0, render_order: 'default',
    allow_mirror_modeling: true, from: [...from], to: [...to], autouv: 0, color: extra.color ?? 0,
    origin: extra.origin ? [...extra.origin] : [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2, (from[2] + to[2]) / 2],
    faces: f, type: 'cube', uuid: uuid(),
  };
  if (extra.rotation) e.rotation = extra.rotation;
  if (extra.inflate) e.inflate = extra.inflate;
  return e;
}
const group = (name, origin, children, opts = {}) => ({
  name, origin: [...origin], rotation: opts.rotation || [0, 0, 0], color: opts.color ?? 0, uuid: uuid(),
  export: true, mirror_uv: false, isOpen: opts.open ?? true, locked: false, visibility: true, autouv: 0,
  selected: false, children, isGroup: true,
});
function translate(node, d) {
  const add = (v) => v.map((x, i) => x + d[i]);
  if (node.isGroup) { node.origin = add(node.origin); node.children.forEach((c) => translate(c, d)); }
  else { node.from = add(node.from); node.to = add(node.to); node.origin = add(node.origin); }
  return node;
}
const flipU = (uv) => [uv[2], uv[1], uv[0], uv[3]];
const flipV = (uv) => [uv[0], uv[3], uv[2], uv[1]];
const rot180 = (uv) => [uv[2], uv[3], uv[0], uv[1]];
const plain = (w, h) => R.plain.uv(0, 0, Math.min(w, 16), Math.min(h, 16));
const sub = (r, x, y, w, h) => r.uv(x, y, x + w, y + h);

// ---------------------------------------------------------------- props
// A shoe is one 2.5 x 1.5 x 5.5 block. toesBack: put away heel-out, as in the photo.
function shoe(name, set, [x, z], rotY, toesBack = true, extraRot = null) {
  const s = set === 'white'
    ? { up: R.shoeW_up, side: R.shoeW_side, toe: R.shoeW_toe, heel: R.shoeW_heel, down: SW.green }
    : { up: R.shoeN_up, side: R.shoeN_side, toe: R.shoeN_toe, heel: R.shoeN_heel, down: SW.white };
  const faces = toesBack
    ? { up: rot180(s.up.uv()), north: s.heel.uv(), south: s.toe.uv(), east: flipU(s.side.uv()), west: s.side.uv(), down: s.down }
    : { up: s.up.uv(), north: s.toe.uv(), south: s.heel.uv(), east: s.side.uv(), west: flipU(s.side.uv()), down: s.down };
  const from = [x - 1.25, 1, z - 2.75], to = [x + 1.25, 2.5, z + 2.75];
  return cube(name, from, to, faces, { rotation: extraRot || [0, rotY, 0], color: 5 });
}
const uwabaki = () => group('indoor_shoes', [0, 1, 0], [
  shoe('shoe_left', 'white', [-2.6, -2.2], 7),
  shoe('shoe_right', 'white', [0.6, -2.6], -4),
], { color: 5 });
const sneakers = () => group('sneakers', [0, 1, 0], [
  shoe('sneaker_left', 'navy', [2.4, -1.8], -9),
  // the other one was kicked in sideways
  shoe('sneaker_right', 'navy', [-2.6, -0.8], 68),
], { color: 5 });
const plasticBag = (at = [-3.4, 3.6], rotY = 16) => group('plastic_bag', [at[0], 1, at[1]], [
  cube('bag', [at[0] - 2, 1, at[1] - 1.5], [at[0] + 2, 4, at[1] + 1.5], {
    north: R.bag_front.uv(), south: flipU(R.bag_front.uv()), east: R.bag_side.uv(), west: R.bag_side.uv(),
    up: R.bag_top.uv(), down: R.bag_top.uv(),
  }, { rotation: [0, rotY, 0], color: 5 }),
  cube('bag_knot', [at[0] - 0.6, 4, at[1] - 0.4], [at[0] + 0.6, 4.6, at[1] + 0.4], { rest: R.bag_top.uv(1.5, 1, 2.5, 2) }, { rotation: [0, rotY, 0], color: 5 }),
], { color: 5 });
// drawstring pouch hanging off the coat hook
const kinchaku = () => group('pouch', [0, 12, 5.7], [
  cube('pouch_string', [-0.12, 9.2, 5.58], [0.12, 12.2, 5.82], { rest: SW.string }, { color: 5 }),
  cube('pouch_gather', [-0.9, 8.5, 4.9], [0.9, 9.3, 6.5], { rest: R.kin_top.uv(1, 0, 2.5, 1) , up: R.kin_top.uv() }, { color: 5 }),
  cube('pouch_body', [-1.75, 4.5, 4.7], [1.75, 8.5, 6.7], {
    north: R.kin_front.uv(), south: R.kin_front.uv(), east: R.kin_side.uv(), west: R.kin_side.uv(),
    up: R.kin_top.uv(), down: R.kin_top.uv(),
  }, { color: 5 }),
], { rotation: [0, -12, 4], color: 5 });
function book(name, top, spine, [x, y, z], [w, t, d], rotY) {
  return cube(name, [x - w / 2, y, z - d / 2], [x + w / 2, y + t, z + d / 2], {
    up: top.uv(), down: top.uv(), west: SW[spine],
    north: sub(R.pages, 0, 0, Math.min(w, 5), Math.min(t, 1)), south: sub(R.pages, 0, 0, Math.min(w, 5), Math.min(t, 1)),
    east: sub(R.pages, 0, 0, Math.min(d, 5), Math.min(t, 1)),
  }, { rotation: [0, rotY, 0], color: 6 });
}
const bookStack = (at = [3, 2.5], lean = 0) => group('books', [at[0], 1, at[1]], [
  book('book_red', R.bookR_top, 'bookR', [at[0], 1, at[1]], [5, 1.2, 3.5], 4),
  book('book_blue', R.bookB_top, 'bookB', [at[0] - 0.2, 2.2, at[1] + 0.1], [4.8, 1, 3.4], -7),
  book('book_yellow', R.bookY_top, 'bookY', [at[0] + 0.3, 3.2, at[1] - 0.2], [5, 0.8, 3.5], 11),
], { rotation: [0, 0, lean], color: 6 });
// door extras, in the closed door's coordinates (they ride along with the door)
const towelOverDoor = () => group('towel', [-3.5, 15, -7], [
  cube('towel_front', [-5.5, 8.6, -7.85], [-1.5, 15.15, -7.55], { north: R.towel.uv(), rest: SW.white }, { color: 7 }),
  cube('towel_top', [-5.5, 15, -7.85], [-1.5, 15.3, -6.2], { up: sub(R.towel, 0, 0, 4, 1.6), rest: SW.white }, { color: 7 }),
  cube('towel_back', [-5.5, 10.8, -6.5], [-1.5, 15.15, -6.2], { south: sub(R.towel, 0, 1.6, 4, 4.4), rest: SW.white }, { color: 7 }),
], { color: 7 });
const tagOnLock = () => group('tag', [4.5, 6.8, -8.1], [
  cube('tag_string', [4.42, 5.9, -8.12], [4.58, 6.8, -8.04], { rest: SW.string }, { color: 7 }),
  cube('tag_card', [3.9, 3.9, -8.16], [5.1, 5.95, -8.06], { north: R.tag.uv(), south: R.tag.uv(), rest: SW.lite }, { color: 7 }),
], { rotation: [0, 0, 9], color: 7 });

// ---------------------------------------------------------------- one locker cell
// door: open angle in degrees (0 = shut). sag: degrees the door has dropped off its top hinge.
function lockerCell({ name = 'locker', door = 0, cream = false, sag = 0, contents = [], doorExtras = [] } = {}) {
  const body = [
    cube('post_hinge', [-8, 0, -8], [-7, 16, 7], {
      north: R.frameV.uv(), east: R.innerSide.uv(), west: flipU(R.outerSide.uv()),
      up: plain(1, 15), down: plain(1, 15), rest: plain(1, 16),
    }, { color: 1 }),
    cube('post_lock', [7, 0, -8], [8, 16, 7], {
      north: flipU(R.frameV.uv()), west: flipU(R.innerSide.uv()), east: R.outerSide.uv(),
      up: plain(1, 15), down: plain(1, 15), rest: plain(1, 16),
    }, { color: 1 }),
    cube('roof', [-7, 15, -8], [7, 16, 7], { north: R.frameTop.uv(), down: R.ceil.uv(), up: plain(14, 15), rest: plain(14, 1) }, { color: 1 }),
    cube('floor', [-7, 0, -8], [7, 1, 7], { north: R.frameBot.uv(), up: flipV(R.floor.uv()), down: plain(14, 15), rest: plain(14, 1) }, { color: 1 }),
    cube('back', [-8, 0, 7], [8, 16, 8], { north: R.innerBack.uv(), south: R.backOuter.uv(), rest: plain(1, 16), up: plain(16, 1), down: plain(16, 1) }, { color: 1 }),
    // hinge knuckles on the frame
    cube('hinge_top', [-7.4, 10.5, -8.1], [-6.6, 13, -7.3], { rest: R.knuckle.uv(), up: SW.chr2, down: SW.chr3 }, { color: 3 }),
    cube('hinge_bottom', [-7.4, 3, -8.1], [-6.6, 5.5, -7.3], { rest: R.knuckle.uv(), up: SW.chr2, down: SW.chr3 }, { color: 3 }),
    // coat hook on the back wall
    cube('hook_arm', [-0.4, 11, 5.4], [0.4, 11.6, 7], { rest: SW.chr2, up: SW.chr, down: SW.chr3 }, { color: 3 }),
    cube('hook_tip', [-0.4, 11.6, 5.4], [0.4, 12.8, 6], { rest: SW.chr2, north: SW.chr, up: SW.chr }, { color: 3 }),
  ];
  const front = cream ? R.doorFrontCream : R.doorFront, back = cream ? R.doorBackCream : R.doorBack;
  const lock = group('lock', [4.5, 7.5, -7.8], [
    cube('lock_cylinder', [3.75, 6.75, -8], [5.25, 8.25, -7.65], { north: R.cyl.uv(), rest: SW.chr2, up: SW.chr, down: SW.chr3 }, { color: 3 }),
  ], { color: 3 });
  let doorParts = [
    cube('door_panel', [-7, 1, -7.5], [7, 15, -6.5], {
      north: front.uv(), south: back.uv(), east: R.doorEdgeV.uv(), west: R.doorEdgeV.uv(), up: R.doorEdgeH.uv(), down: R.doorEdgeH.uv(),
    }, { color: 2 }),
    cube('name_card', [2.5, 11, -7.75], [6.5, 13.5, -7.5], { north: R.label.uv(), rest: SW.chr2, up: SW.chr, down: SW.chr3 }, { color: 4 }),
    cube('lock_bezel', [3, 6, -7.65], [6, 9, -7.5], { north: R.bezel.uv(), rest: SW.chr3, up: SW.chr2 }, { color: 3 }),
    lock,
    ...doorExtras.map((f) => f()),
  ];
  // a door hanging off its bottom hinge: tilt it in its own plane about that hinge
  if (sag) doorParts = [group('door_sag', [-7, 4.25, -7.6], doorParts, { rotation: [0, 0, -sag], color: 2 })];
  const gDoor = group('door', [-7, 8, -7.6], doorParts, { rotation: [0, OPEN_SIGN_POSE * door, 0], color: 2 });
  const gBody = group('body', [0, 0, 0], body, { color: 1, open: false });
  const kids = [gBody, gDoor];
  if (contents.length) kids.push(group('contents', [0, 1, 0], contents.map((f) => f()), { color: 5 }));
  const root = group(name, [0, 0, 0], kids);
  return { root, body: gBody, door: gDoor, lock };
}

// decorative lockers: left open, with somebody's things inside. Not interactive.
const DECO = {
  shoes:    { door: 118, contents: [uwabaki] },
  sneakers: { door: 96, cream: true, contents: [sneakers, () => plasticBag()] },
  towel:    { door: 34, contents: [() => bookStack([2.6, 2.2])], doorExtras: [towelOverDoor] },
  pouch:    { door: 112, contents: [kinchaku, uwabaki], doorExtras: [tagOnLock] },
  broken:   { door: 64, sag: 9, contents: [() => bookStack([-2.5, 1.5], 0), () => plasticBag([3.2, 3.4], -24)] },
};

// ---------------------------------------------------------------- interactive locker contents
// A shelf; above it standing textbooks and a school bag on the coat hook (after the photo),
// below it a ninja headband, a shuriken stuck in the back wall and a manga volume.
// Each item is its own bone with a glow shell and sparkles for the hover effect.
const GLOW_INFLATE = 0.22;
function glowShell(item, cubes, center, { inflate = GLOW_INFLATE, faces = null, sparkR = 2 } = {}) {
  const shells = cubes.map((c) => {
    const e = cube(`${c.name}_glow`, c.from, c.to, faces || { rest: R.glow.uv() },
      { origin: c.origin, rotation: c.rotation, inflate, color: 8 });
    return e;
  });
  const [x, y, z] = center;
  const spark = (n, dx, dy, dz) => cube(`${item}_sparkle_${n}`, [x + dx - 0.3, y + dy - 0.3, z + dz - 0.3], [x + dx + 0.3, y + dy + 0.3, z + dz + 0.3],
    { rest: R.sparkle.uv() }, { rotation: [0, 45, 45], color: 8 });
  const sparkles = group(`${item}_sparkles`, center, [
    spark(1, sparkR, 0.8, 0), spark(2, -sparkR * 0.6, 1.6, sparkR * 0.7), spark(3, -sparkR * 0.5, -0.2, -sparkR * 0.8),
  ], { color: 8 });
  return group(`${item}_glow`, center, [...shells, sparkles], { color: 8 });
}
function standingBook(i, x0, thk, h, { lean = 0, z0 = -2.5 } = {}) {
  const hh = Math.min(h, 6);
  return cube(`book_${i}`, [x0, 8, z0], [x0 + thk, 8 + h, z0 + 4], {
    north: sub(R['spine' + i], 0, 0, thk, hh), south: sub(R['spine' + i], 0, 0, thk, hh),
    east: sub(R['cover' + i], 0, 0, 4, hh), west: flipU(sub(R['cover' + i], 0, 0, 4, hh)),
    up: sub(R.pages, 0, 0, thk, 1), down: sub(R.pages, 0, 0, thk, 1),
  }, { origin: [x0, 8, z0 + 2], rotation: lean ? [0, 0, lean] : null, color: 6 });
}
function interactiveContents() {
  const shelf = group('shelf', [0, 7.7, 0], [
    cube('shelf', [-7, 7.4, -6.3], [7, 8, 7], { north: R.frameBot.uv(), up: plain(14, 13.3), down: plain(14, 13.3), rest: plain(13.3, 0.6) }, { color: 1 }),
  ], { color: 1 });
  const items = {};
  const item = (key, center, cubes, glowOpts) => {
    const g = group(`item_${key}`, center, [...cubes, glowShell(key, cubes, center, glowOpts)], { color: 6 });
    items[key] = { group: g, glow: g.children[g.children.length - 1] };
    items[key].sparkles = items[key].glow.children[items[key].glow.children.length - 1];
    return g;
  };
  // top: textbooks standing against the hinge-side wall, the orange one leaning
  item('books', [-4.6, 10.7, -0.5], [
    standingBook(0, -6.8, 1.3, 5.6),
    standingBook(1, -5.45, 1.1, 5.4, { z0: -2.3 }),
    standingBook(2, -4.3, 0.9, 4.8, { lean: 7, z0: -2.6 }),
    standingBook(3, -3.3, 1.0, 5.0, { z0: -2.4 }),
  ], { sparkR: 2.6 });
  // top: school bag hung on the coat hook by its handle
  item('bag', [0, 10.4, 3.85], [
    cube('bag_body', [-2.25, 8.2, 2.6], [2.25, 12.2, 5.1], {
      north: R.sbag_front.uv(), south: R.sbag_front.uv(), east: R.sbag_side.uv(), west: R.sbag_side.uv(), up: R.sbag_top.uv(), down: R.sbag_top.uv(),
    }, { color: 6 }),
    cube('bag_handle', [-0.6, 12.2, 3.7], [0.6, 12.95, 4.0], { rest: SW.string }, { color: 6 }),
    cube('bag_handle_over_hook', [-0.6, 12.85, 3.7], [0.6, 13.15, 6.05], { rest: SW.string }, { color: 6 }),
  ], { sparkR: 3 });
  // bottom: headband tied in a loop, plate facing out, tails trailing behind the knot
  const cx = -3.4, cz = -1.4, RAD = 1.9;
  const band = [];
  for (let k = 1; k < 8; k++) {
    const a = k * 45 * Math.PI / 180;
    const px = cx + RAD * Math.sin(a), pz = cz - RAD * Math.cos(a);
    band.push(cube(`band_${k}`, [px - 0.85, 1, pz - 0.1], [px + 0.85, 2.5, pz + 0.1], {
      north: R.hb_band.uv(), south: R.hb_band.uv(), rest: sub(R.hb_band, 0, 0, 0.5, 1.5),
    }, { origin: [px, 1.75, pz], rotation: [0, ((-k * 45 + 540) % 360) - 180, 0], color: 6 }));
  }
  const kz = cz + RAD;
  item('headband', [cx, 1.75, cz], [
    cube('plate', [cx - 1.5, 1, cz - RAD - 0.22], [cx + 1.5, 2.5, cz - RAD + 0.12], { north: R.hb_plate.uv(), rest: SW.chr3, up: SW.chr2 }, { color: 6 }),
    ...band,
    cube('knot', [cx - 0.45, 1, kz - 0.2], [cx + 0.45, 2.6, kz + 0.5], { rest: R.hb_band.uv() }, { color: 6 }),
    cube('tail_1', [cx - 0.5, 1, kz + 0.4], [cx + 0.5, 1.15, kz + 2.8], { up: R.hb_band.uv(), rest: SW.dk }, { origin: [cx, 1, kz + 0.4], rotation: [0, 28, 0], color: 6 }),
    cube('tail_2', [cx - 0.5, 1, kz + 0.4], [cx + 0.5, 1.12, kz + 2.4], { up: R.hb_band.uv(), rest: SW.dk }, { origin: [cx, 1, kz + 0.4], rotation: [0, -22, 0], color: 6 }),
  ], { sparkR: 2.6 });
  // bottom: shuriken thrown into the floor behind the manga, stuck upright and leaning back
  const sc = [2.4, 2.6, 2.8];
  const starFaces = { north: R.shuriken.uv(), south: R.shuriken.uv(), rest: R.clear.uv(0.25, 0.25, 0.75, 0.75) };
  const star = cube('shuriken', [sc[0] - 2.25, sc[1] - 2.25, sc[2] - 0.05], [sc[0] + 2.25, sc[1] + 2.25, sc[2] + 0.05], starFaces, { origin: sc, rotation: [12, 0, 20], color: 6 });
  item('shuriken', sc, [star], {
    inflate: 0.3, sparkR: 2.2,
    faces: { north: R.shurikenGlow.uv(), south: R.shurikenGlow.uv(), rest: R.clear.uv(0.25, 0.25, 0.75, 0.75) },
  });
  // bottom: manga volume lying cover-up, title toward the back so it reads upright to the viewer
  item('manga', [2.4, 1.3, -1.2], [
    cube('manga', [0.65, 1, -3.7], [4.15, 1.6, 1.3], {
      up: rot180(R.manga_front.uv()), down: R.manga_back.uv(),
      north: sub(R.pages, 0, 0, 3.5, 0.6), south: sub(R.pages, 0, 0, 3.5, 0.6), east: sub(R.pages, 0, 0, 5, 0.6), west: SW.dk,
    }, { rotation: [0, -12, 0], color: 6 }),
  ], { sparkR: 2.6 });
  return { shelf, items };
}

// ---------------------------------------------------------------- animations
const r2 = (v) => Math.round(v * 100) / 100;
const kf = (channel, time, [x, y, z]) => ({
  channel, data_points: [{ x: String(r2(x)), y: String(r2(y)), z: String(r2(z)) }], uuid: uuid(),
  time: Math.round(time * 1000) / 1000, color: -1, interpolation: 'linear',
});
const STEP = 0.05; // one game tick
// fn(t) -> [x,y,z], sampled every tick over [t0, t1]
function sample(channel, t0, t1, fn) {
  const out = [];
  for (let i = 0; i <= Math.round((t1 - t0) / STEP); i++) { const t = t0 + i * STEP; out.push(kf(channel, t, fn(t))); }
  return out;
}
// merge key lists, later keys win on equal times
function keys(...lists) {
  const m = new Map();
  for (const k of lists.flat()) m.set(k.channel + '@' + k.time, k);
  return [...m.values()].sort((a, b) => a.time - b.time);
}
const clamp01 = (v) => Math.max(0, Math.min(1, v));
const easeOut = (t) => 1 - Math.pow(1 - clamp01(t), 3);
const easeIn = (t) => Math.pow(clamp01(t), 3);
const easeInOut = (t) => { t = clamp01(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
const easeOutBack = (t, s = 2.2) => { t = clamp01(t) - 1; return 1 + t * t * ((s + 1) * t + s); };
// starts at `from`, flings toward `to` and rings out around it
const spring = (from, to, tau, w, z) => to + (from - to) * Math.exp(-z * tau) * Math.cos(w * tau);
// a bounce off a hard stop: only ever on one side of zero
const bounce = (amp, tau, w, z) => amp * Math.exp(-z * tau) * Math.abs(Math.sin(w * tau));
const lerp = (a, b, t) => a + (b - a) * t;
// door angles below are written as "degrees open"; this turns them into Blockbench's sign
const doorKeys = (list) => list.map((k) => (k.channel === 'rotation'
  ? { ...k, data_points: [{ ...k.data_points[0], y: String(r2(OPEN_SIGN_ANIM * Number(k.data_points[0].y))) }] }
  : k));

function anim(name, length, loop, tracks) {
  const animators = {};
  for (const [g, ks] of tracks) animators[g.uuid] = { name: g.name, type: 'bone', keyframes: ks };
  return {
    uuid: uuid(), name: `animation.locker.${name}`, loop, override: false, length, snapping: 20,
    selected: false, anim_time_update: '', blend_weight: '', start_delay: '', loop_delay: '', animators,
  };
}

function lockerAnimations({ root, door, lock }) {
  const OPEN = 116;  // resting open angle: past square, so the door face still reads from the front
  const POP = 5;     // how far the door springs out when the latch lets go
  return [
    // OPEN: key turns (overshoots, settles), door is pushed in a hair to free the latch, the
    // latch pops it ajar, a beat, then the door is flung open and rings out on the hinge
    // while the key springs back.
    anim('open', 0.9, 'hold', [
      [lock, keys(
        sample('rotation', 0, 0.15, (t) => [0, 0, 90 * easeOutBack(t / 0.15, 1.6)]),
        sample('rotation', 0.15, 0.35, () => [0, 0, 90]),
        sample('rotation', 0.35, 0.65, (t) => [0, 0, spring(90, 0, t - 0.35, 16, 11)]),
        [kf('rotation', 0.9, [0, 0, 0])],
      )],
      [door, doorKeys(keys(
        sample('rotation', 0, 0.1, (t) => [0, -1.2 * easeInOut(t / 0.1), 0]),
        [kf('rotation', 0.15, [0, POP, 0])],
        sample('rotation', 0.2, 0.3, (t) => [0, lerp(POP - 1, POP - 0.5, (t - 0.2) / 0.1), 0]),
        sample('rotation', 0.35, 0.9, (t) => [0, spring(POP - 0.5, OPEN, t - 0.3, 12, 8.5), 0]),
        [kf('rotation', 0.9, [0, OPEN, 0])],
        sample('position', 0, 0.1, (t) => [0, 0, 0.2 * easeInOut(t / 0.1)]),
        [kf('position', 0.15, [0, 0, 0]), kf('position', 0.9, [0, 0, 0])],
      ))],
    ]),
    // OPEN_IDLE: hanging open, the door drifts a couple of degrees as if in a draft.
    anim('open_idle', 4, 'loop', [
      [door, doorKeys(sample('rotation', 0, 4, (t) => [0, OPEN + 1.1 * (1 - Math.cos(2 * Math.PI * t / 4)) + 0.25 * Math.sin(2 * Math.PI * t / 2), 0]))],
    ]),
    // CLOSE: a short wind-up (pulled a little wider), the door accelerates shut and slams,
    // bounces off the frame twice, the cabinet jolts and squashes, the key rattles.
    anim('close', 0.8, 'hold', [
      [door, doorKeys(keys(
        sample('rotation', 0, 0.1, (t) => [0, OPEN + 6 * easeOut(t / 0.1), 0]),
        sample('rotation', 0.15, 0.3, (t) => [0, (OPEN + 6) * (1 - easeIn((t - 0.1) / 0.2)), 0]),
        sample('rotation', 0.3, 0.6, (t) => [0, bounce(10, t - 0.3, Math.PI / 0.1, 10), 0]),
        [kf('rotation', 0.8, [0, 0, 0])],
      ))],
      [lock, keys(
        [kf('rotation', 0, [0, 0, 0])],
        sample('rotation', 0.3, 0.6, (t) => [0, 0, 16 * Math.exp(-9 * (t - 0.3)) * Math.sin(Math.PI / 0.1 * (t - 0.3))]),
        [kf('rotation', 0.6, [0, 0, 0]), kf('rotation', 0.8, [0, 0, 0])],
      )],
      [root, keys(
        [kf('scale', 0, [1, 1, 1]), kf('scale', 0.3, [1, 1, 1])],
        sample('scale', 0.3, 0.55, (t) => { const s = 0.03 * Math.exp(-12 * (t - 0.3)) * Math.cos(Math.PI / 0.1 * (t - 0.3)); return [1 + s, 1 - s, 1 + s * 0.4]; }),
        [kf('scale', 0.6, [1, 1, 1]), kf('scale', 0.8, [1, 1, 1])],
        [kf('position', 0, [0, 0, 0]), kf('position', 0.3, [0, 0, 0])],
        sample('position', 0.3, 0.55, (t) => [0, 0, 0.3 * Math.exp(-10 * (t - 0.3)) * Math.cos(Math.PI / 0.1 * (t - 0.3))]),
        [kf('position', 0.6, [0, 0, 0]), kf('position', 0.8, [0, 0, 0])],
      )],
    ]),
    // LOCKED: tried while locked. The key jams a quarter of the way, gets forced twice,
    // the door rattles in its frame, the key snaps back.
    anim('locked', 0.7, 'once', [
      [lock, keys(
        sample('rotation', 0, 0.1, (t) => [0, 0, 22 * easeOut(t / 0.1)]),
        [kf('rotation', 0.15, [0, 0, 17]), kf('rotation', 0.2, [0, 0, 25]), kf('rotation', 0.25, [0, 0, 18]), kf('rotation', 0.3, [0, 0, 24])],
        sample('rotation', 0.35, 0.6, (t) => [0, 0, spring(24, 0, t - 0.3, 18, 12)]),
        [kf('rotation', 0.7, [0, 0, 0])],
      )],
      [door, doorKeys(keys(
        [kf('rotation', 0, [0, 0, 0]), kf('rotation', 0.1, [0, 0, 0])],
        sample('rotation', 0.15, 0.55, (t) => [0, bounce(3, t - 0.1, Math.PI / 0.1, 6), 0]),
        [kf('rotation', 0.7, [0, 0, 0])],
        [kf('position', 0, [0, 0, 0]), kf('position', 0.1, [0, 0, 0])],
        sample('position', 0.15, 0.55, (t) => [0, 0, 0.12 * Math.exp(-6 * (t - 0.1)) * Math.cos(Math.PI / 0.1 * (t - 0.1))]),
        [kf('position', 0.7, [0, 0, 0])],
      ))],
    ]),
  ];
}

// Hover set for one item, four clips each (play them from one controller per item):
//   <item>.rest        loop   glow hidden, item at rest (the idle state)
//   <item>.hover_start once   the item lifts off with an overshoot, glow blooms in
//   <item>.hover       loop   it floats and bobs, glow breathes, sparkles orbit and twinkle
//   <item>.hover_end   once   it settles back with a small bump, glow fades out
// lift: float height. tilt: rotation it presents itself at. sway: [x,y,z] wobble while
// floating. slide: z offset (negative = toward the viewer). spin: degrees per loop about Z.
const HOVER = {
  books:    { lift: 0.9, tilt: [6, 0, 0], sway: [0, 0, 2] },
  bag:      { lift: 0.8, tilt: [0, 0, 0], sway: [0, 0, 4] },
  headband: { lift: 1.8, tilt: [24, 0, 0], sway: [0, 7, 0] },
  manga:    { lift: 2.0, tilt: [40, 0, 0], sway: [0, 0, 3] },
  shuriken: { lift: 1.3, tilt: [0, 0, 0], sway: [0, 0, 0], slide: -1.2, spin: 360 },
};
function itemAnimations(items) {
  const out = [];
  for (const [key, it] of Object.entries(items)) {
    const P = { slide: 0, spin: 0, ...HOVER[key] };
    const T0 = 0.35, LOOP = 2, T1 = 0.3;
    const add = (v, w) => v.map((a, i) => a + w[i]);
    const sc = (v, s) => v.map((a) => a * s);
    // rest
    out.push(anim(`${key}.rest`, 0.05, 'loop', [
      [it.group, [kf('position', 0, [0, 0, 0]), kf('rotation', 0, [0, 0, 0])]],
      [it.glow, [kf('scale', 0, [0, 0, 0])]],
    ]));
    // hover_start: lift off with an overshoot (anticipation is the tiny dip first), glow blooms
    out.push(anim(`${key}.hover_start`, T0, 'once', [
      [it.group, keys(
        [kf('position', 0, [0, 0, 0]), kf('position', 0.05, [0, -0.12, 0])],
        sample('position', 0.1, T0, (t) => [0, P.lift * easeOutBack((t - 0.05) / (T0 - 0.05), 1.8), P.slide * easeOut((t - 0.05) / (T0 - 0.05))]),
        sample('rotation', 0, T0, (t) => add(sc(P.tilt, easeOut(t / T0)), [0, 0, P.spin ? -180 * (1 - easeOut(t / T0)) : 0])),
      )],
      [it.glow, sample('scale', 0, T0, (t) => { const s = Math.max(0, easeOutBack(t / T0, 2.4)); return [s, s, s]; })],
      [it.sparkles, keys(
        sample('rotation', 0, T0, (t) => [0, -90 * (1 - easeOut(t / T0)), 0]),
        sample('scale', 0, T0, (t) => { const s = easeOut(t / T0) * 0.85; return [s, s, s]; }),
      )],
    ]));
    // hover: float and bob, sway, breathing glow, orbiting twinkling sparkles
    out.push(anim(`${key}.hover`, LOOP, 'loop', [
      [it.group, keys(
        sample('position', 0, LOOP, (t) => [0, P.lift + 0.3 * Math.sin(2 * Math.PI * t / LOOP), P.slide]),
        sample('rotation', 0, LOOP, (t) => add(add(P.tilt, sc(P.sway, Math.sin(2 * Math.PI * t / LOOP))), [0, 0, P.spin * t / LOOP])),
      )],
      [it.glow, sample('scale', 0, LOOP, (t) => { const s = 1 + 0.06 * Math.sin(2 * Math.PI * t * 2 / LOOP); return [s, s, s]; })],
      [it.sparkles, keys(
        sample('rotation', 0, LOOP, (t) => [0, 360 * t / LOOP, 0]),
        sample('scale', 0, LOOP, (t) => { const s = 0.85 + 0.35 * Math.abs(Math.sin(3 * Math.PI * t / LOOP)); return [s, s, s]; }),
      )],
    ]));
    // hover_end: drop back (gravity), a small bump on landing, glow fades, a re-stuck shuriken quivers
    out.push(anim(`${key}.hover_end`, T1, 'once', [
      [it.group, keys(
        sample('position', 0, 0.2, (t) => [0, P.lift * (1 - easeIn(t / 0.2)), P.slide * (1 - easeIn(t / 0.2))]),
        [kf('position', 0.25, [0, P.slide ? 0 : 0.12, 0]), kf('position', T1, [0, 0, 0])],
        sample('rotation', 0, 0.2, (t) => sc(P.tilt, 1 - easeInOut(t / 0.2))),
        P.slide ? [kf('rotation', 0.25, [0, 0, 5]), kf('rotation', 0.3, [0, 0, 0])] : [kf('rotation', T1, [0, 0, 0])],
      )],
      [it.glow, keys(sample('scale', 0, 0.2, (t) => { const s = 1 - easeIn(t / 0.2); return [s, s, s]; }), [kf('scale', T1, [0, 0, 0])])],
      [it.sparkles, sample('scale', 0, 0.2, (t) => { const s = 0.85 * (1 - easeOut(t / 0.2)); return [s, s, s]; })],
    ]));
  }
  return out;
}

// ---------------------------------------------------------------- the wall
// A free-standing bank like the reference: end panels, a dark kick plinth, a top cap.
// Closed cells are the interactive locker (grey or cream); open ones are DECO variants.
const WALL = [ // top row first, viewer's left to right
  ['closed', 'cream', 'broken', 'closed', 'towel', 'closed'],
  ['cream', 'shoes', 'closed', 'cream', 'closed', 'pouch'],
  ['closed', 'closed', 'closed', 'sneakers', 'cream', 'closed'],
];
const PLINTH = 4;
function buildWall() {
  const rows = WALL.length, cols = WALL[0].length;
  const half = cols * 8;
  const cells = [];
  WALL.forEach((row, ri) => row.forEach((kind, c) => {
    const r = rows - 1 - ri;                       // r = 0 is the bottom row
    const x = half - 8 - c * 16, y = PLINTH + r * 16;
    const opts = kind === 'closed' ? {} : kind === 'cream' ? { cream: true } : DECO[kind];
    const name = `r${r}_c${c}_${kind}`;
    cells.push(translate(lockerCell({ ...opts, name }).root, [x, y, 0]));
  }));
  const top = PLINTH + rows * 16;
  const frame = [];
  // plinth: recessed dark kick plate under each column
  for (let c = 0; c < cols; c++) {
    const x = half - 8 - c * 16;
    frame.push(cube(`plinth_${c}`, [x - 8, 0, -7], [x + 8, PLINTH, 7.5], { north: R.kick.uv(), rest: plain(16, PLINTH) }, { color: 1 }));
    frame.push(cube(`cap_${c}`, [x - 8, top, -8.4], [x + 8, top + 1, 8], { north: R.frameTop.uv(0, 0, 14, 1), rest: plain(16, 16) }, { color: 1 }));
  }
  // end panels: thick, light, a little proud of the doors, split per row to keep pixel density
  for (const side of [1, -1]) {
    const x0 = side > 0 ? half : -half - 1.5, x1 = x0 + 1.5;
    const segs = [[0, PLINTH], ...Array.from({ length: rows }, (_, i) => [PLINTH + i * 16, PLINTH + (i + 1) * 16]), [top, top + 1]];
    segs.forEach(([y0, y1], i) => {
      const hgt = y1 - y0;
      const outer = side > 0 ? R.outerSide.uv(0, 0, 15, Math.min(hgt, 16)) : flipU(R.outerSide.uv(0, 0, 15, Math.min(hgt, 16)));
      frame.push(cube(`end_${side > 0 ? 'left' : 'right'}_${i}`, [x0, y0, -8.5], [x1, y1, 8], {
        north: R.endFront.uv(0, 0, 1.5, Math.min(hgt, 16)), [side > 0 ? 'east' : 'west']: outer, rest: plain(16, Math.min(hgt, 16)),
      }, { color: 1 }));
    });
  }
  return group('locker_wall', [0, 0, 0], [group('frame', [0, 0, 0], frame, { color: 1, open: false }), ...cells]);
}

// ---------------------------------------------------------------- write
function serialize(roots) {
  const elements = [];
  const walk = (n) => {
    if (!n.isGroup) { elements.push(n); return n.uuid; }
    const { isGroup, ...g } = n;
    return { ...g, children: n.children.map(walk) };
  };
  const outliner = roots.map(walk);
  return { elements, outliner };
}
function writeModel(file, name, roots, { animations = [], png, texName = 'locker.png', box = [1, 1, 0] } = {}) {
  const { elements, outliner } = serialize(roots);
  const model = {
    meta: { format_version: '4.10', model_format: 'bedrock', box_uv: false },
    name, model_identifier: name, visible_box: box,
    variable_placeholders: '', variable_placeholder_buttons: [], timeline_setups: [], unhandled_root_fields: {},
    resolution: { width: ATLAS, height: ATLAS },
    elements, outliner,
    textures: [{
      path: path.join(OUT, texName), name: texName, folder: '', namespace: '', id: '0',
      group: '', width: W, height: H, uv_width: ATLAS, uv_height: ATLAS, particle: false,
      use_as_default: false, layers_enabled: false, sync_to_project: '', render_mode: 'default',
      render_sides: 'auto', pbr_channel: 'color', frame_time: 1, frame_order_type: 'loop',
      frame_order: '', frame_interpolate: false, visible: true, internal: true, saved: true,
      uuid: uuid(), relative_path: texName, source: 'data:image/png;base64,' + png.toString('base64'),
    }],
    animations,
  };
  fs.writeFileSync(path.join(OUT, file), JSON.stringify(model));
  console.log(`${file}: ${elements.length} cubes${animations.length ? `, ${animations.length} animations` : ''}`);
}

const { main, cream, glowmask } = A.pngs();
fs.writeFileSync(path.join(OUT, 'locker.png'), main);
fs.writeFileSync(path.join(OUT, 'locker_cream.png'), cream);
fs.writeFileSync(path.join(OUT, 'locker_glowmask.png'), glowmask);

const inside = interactiveContents();
const interactive = lockerCell({ contents: [() => inside.shelf, ...Object.values(inside.items).map((it) => () => it.group)] });
writeModel('locker.bbmodel', 'locker', [interactive.root], {
  animations: [...lockerAnimations(interactive), ...itemAnimations(inside.items)], png: main,
});
for (const [k, opts] of Object.entries(DECO)) {
  writeModel(`locker_deco_${k}.bbmodel`, `locker_deco_${k}`, [lockerCell({ ...opts, name: `locker_deco_${k}` }).root], { png: main });
}
writeModel('locker_wall.bbmodel', 'locker_wall', [buildWall()], { png: main, box: [6, 4, 0] });
